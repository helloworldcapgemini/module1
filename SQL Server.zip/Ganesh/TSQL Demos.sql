-- To Show all the databases
EXECUTE SP_Databases;
SELECT NAME FROM sys.sysdatabases 

-- To Create a DATABASE
CREATE DATABASE training

-- To select a DATABASE:
USE training

--To see the tables in the current DATABASE
SELECT NAME FROM sys.tables

-- Create a TABLE
CREATE TABLE Employee(EmployeeID INT,EmployeeName VARCHAR(20),Age INT)

-- To see the structure of the TABLE
SP_HELP Employee

-- To delete a TABLE
drop TABLE Employee

-- To CREATE a TABLE with primary key and non-null value fields
CREATE TABLE Employee(
EmployeeID INT PRIMARY KEY,
EmployeeName VARCHAR(20) NOT NULL ,
Age INT NOT NULL
)

-- To insert a record :
INSERT INTO Employee(EmployeeID,EmployeeName,Age) VALUES(101,'Abishek',27);

--Sample Select Syntax
--The clauses in the SELECT statement must be written in the syntactical order
 --given in the below syntax
SELECT select_list
[INTO new_table_]
FROM table
[WHERE search_condition]
[GROUP BY group_by_expression]
[HAVING search_condition]
[ORDER BY order_expression [ASC | DESC] ];



-- To retreive the records (ALL Fields)
SELECT * FROM Employee; 

--you can use * as shorthand, but this notation is not recommended


-- To retreive the records (Particular Fields)
SELECT EmployeeName,Age FROM Employee

-- To retreive a particular record:
SELECT * FROM Employee WHERE EmployeeID = 101

-- Use of "as" and "arithmetic operators":
SELECT EmployeeId,EmployeeName,Age,Age-1 AS 'New Age' from Employee

-- To add a new column:
ALTER TABLE Employee ADD City VARCHAR(20);


--To update a record:	
UPDATE Employee SET City = 'Chennai' WHERE EmployeeId = 101;

-- Inserting Few more records
INSERT INTO Employee(EmployeeID,EmployeeName,Age,City) VALUES(102,'Ganesh',39,'Mumbai');
INSERT INTO Employee(EmployeeID,EmployeeName,Age,City) VALUES(103,'Ajit',34,'Pune');
INSERT INTO Employee(EmployeeID,EmployeeName,Age,City) VALUES(104,'Karthik',28,'Bangalore');
INSERT INTO Employee(EmployeeID,EmployeeName,Age,City) VALUES(105,'Shilpa',24,'Mumbai');


-- Use of "and" : [Logical operator]
SELECT * FROM Employee WHERE City = 'Chennai' OR Age = 20;

-- NotEqual<> : [Relational Operator]
SELECT * FROM Employee WHERE Age<>20;

-- Between Operator
SELECT * FROM Employee WHERE Age BETWEEN 18 AND 27;

-- NOT Between Usage
SELECT * FROM Employee WHERE Age NOT BETWEEN 18 AND 27;

-- IN Operator
SELECT * FROM Employee WHERE City IN('Chennai','Mumbai')

-- NOT IN Operator
SELECT * FROM Employee WHERE City NOT IN('Bangalore','Pune')

-- Like operator :
SELECT * FROM Employee WHERE  EmployeeName LIKE 'A%'

-- Sorting in Ascending Order (default)
SELECT * FROM Employee ORDER BY Age ASC

-- Sorting in Descending Order
SELECT * FROM Employee ORDER BY Age DESC

-- To Eliminate Duplicate record
SELECT DISTINCT City FROM Employee

-- Aggregate Functions [max,min,sum,avg..]
SELECT City, MAX(age) 'Max Age' FROM Employee
Group By City

SELECT  Count(EmployeeId) 'Total Emp' FROM Employee


SELECT City, Count(EmployeeId) 'Total Emp' FROM Employee
Where City In ('Mumbai', 'Pune')
Group By City

SELECT City, Count(EmployeeId) 'Total Emp' FROM Employee
Where City In ('Mumbai', 'Pune')
Group By City
Having Count(EmployeeId) <= 1


Select Gender, Avg(Income) from Customer
Group By Gender
Having Avg(Income) > 20000

-- To count number of Records
SELECT COUNT(*)'Total Employees' FROM Employee

-- Group BY
SELECT City, COUNT(*) AS 'No Of Employees' FROM Employee GROUP BY City

-- Having
SELECT City, MAX(Age) AS 'Maximum Age' FROM Employee GROUP BY City HAVING MAX(Age) > 30


-- To Delete a record
DELETE FROM Employee WHERE EmployeeID = 105;

-- To delete contents of the table
TRUNCATE Employee;

-- To delete a Table
DROP TABLE Employee;

-- Creating a Table with auto_increment primary key value
CREATE TABLE Employee(
EmployeeID INT IDENTITY(1001,1) PRIMARY KEY,
EmployeeName VARCHAR(20) NOT NULL ,
Age INT  NOT NULL)


INSERT INTO Employee(EmployeeName,Age) VALUES ('Ajit',34)

-- Create UserDefined Data Type
CREATE TYPE UDT_CITY FROM VARCHAR(25) NOT NULL

-- Making use of UserDefined Data Type
ALTER TABLE Employee ADD City UDT_CITY;

-- Deleting Table
DROP TABLE Employee;

-- Dropping UserDefined Data Type
DROP TYPE UDT_CITY

-- Entity Integrity (each row is unique)
CREATE TABLE Employee
(
	EmployeeID CHAR(9) CONSTRAINT pkEmpID PRIMARY KEY,
	EmailID VARCHAR(25) CONSTRAINT uqEmail UNIQUE	
)

-- Domain Integrity (Set of Values)
ALTER TABLE Employee 
ADD CONSTRAINT ckEmpID CHECK(EmployeeID LIKE 'IGATE[0-9][0-9][0-9][0-9]'),
Gender CHAR(1) CONSTRAINT ckGender CHECK(Gender in ('M','F','T')),
City VARCHAR(25) CONSTRAINT dftCity DEFAULT 'Bangalore',
BasicPay INT CONSTRAINT ckBasicPay CHECK(BasicPay BETWEEN 2000 AND 5000)

SP_HELP Employee

INSERT INTO Employee(EmployeeID,EmailID,Gender,BasicPay) VALUES('IGATE1234','karthik@igate.com','M',2500)

SELECT * FROM Employee

--Disabling Constraints
ALTER TABLE Employee NOCHECK CONSTRAINT ckBasicPay
INSERT INTO Employee(EmployeeID,EmailID,Gender,BasicPay) VALUES('IGATE4321','sample@igate.com','M',1500)

--Enabling Constraints
ALTER TABLE Employee CHECK CONSTRAINT ckBasicPay
INSERT INTO Employee(EmployeeID,EmailID,Gender,BasicPay) VALUES('IGATE4344','demo@igate.com','M',1500)


--Dropping Constraint
ALTER TABLE Employee DROP CONSTRAINT ckBasicPay

-- WITH CHECK(Adding Constrainst by checking against existing DATA)
ALTER TABLE Employee WITH CHECK ADD CONSTRAINT ckBasicPay CHECK(BasicPay BETWEEN 2000 AND 5000)

-- WITH NOCHECK(Adding Constrainst without checking against existing DATA)
ALTER TABLE Employee WITH NOCHECK ADD CONSTRAINT ckBasicPay CHECK(BasicPay BETWEEN 2000 AND 5000)

-- Creating Department Table
CREATE TABLE Department
(
	DeptID INT CONSTRAINT pkDeptID PRIMARY KEY,
    DeptName VARCHAR(15)
)

-- Referential Integrity (Enforce relationship between tables)
ALTER TABLE Employee 
ADD DeptID INT CONSTRAINT fkDeptID FOREIGN KEY REFERENCES Department(DeptID)

-- Creating a Rule
CREATE RULE genderRule AS @gender IN ('M','F','T')

-- Binding a Rule
SP_BINDRULE genderRule,'Employee.Gender'

-- Unbinding a Rule
SP_UNBINDRULE 'Employee.Gender'

-- Dropping a Rule
DROP RULE genderRule

-- Unique Identifier
CREATE TABLE SampleTable(ID UNIQUEIDENTIFIER NOT NULL)
INSERT INTO SampleTable values(NEWID());
SELECT ID FROM SampleTable;

-- ALL Operator
CREATE TABLE T1(ID INT NOT NULL)
INSERT INTO T1 VALUES(1);
INSERT INTO T1 VALUES(3);
INSERT INTO T1 VALUES(5);
INSERT INTO T1 VALUES(7);
INSERT INTO T1 VALUES(9);

CREATE TABLE T2(ID INT NOT NULL)
INSERT INTO T2 VALUES(2);
INSERT INTO T2 VALUES(4);
INSERT INTO T2 VALUES(6);
INSERT INTO T2 VALUES(8);
INSERT INTO T2 VALUES(10);

-- ALL Operator
SELECT ID FROM T1 WHERE ID < ALL(SELECT ID FROM T2);
SELECT ID FROM T2 WHERE ID > ALL(SELECT ID FROM T1);

-- ANY Operator
SELECT ID FROM T1 WHERE ID < ANY(SELECT ID FROM T2);
SELECT ID FROM T2 WHERE ID > ANY(SELECT ID FROM T1 WHERE ID >=5);

INSERT INTO T1 VALUES(2);
INSERT INTO T2 VALUES(5);
INSERT INTO T1 VALUES(6);

-- SET Operations

-- UNION (Without Duplicate Values)
SELECT ID AS 'Union' FROM T1 UNION SELECT ID FROM T2

-- UNION ALL (With Duplicate Values)
SELECT ID AS 'Union ALL' FROM T1 UNION ALL SELECT ID FROM T2

-- INTERSECT (Common Values in both Tables)
SELECT ID AS 'Intersect' FROM T1 INTERSECT SELECT ID FROM T2

-- EXCEPT
SELECT ID AS 'EXCEPT' FROM T1 EXCEPT SELECT ID FROM T2

-- Subqueries
--Single Row SubQuery(Subquery Returns 1 value)
SELECT MAX(AGE) FROM Employee WHERE AGE < (SELECT MAX(AGE) FROM Employee WHERE AGE < (SELECT MAX(AGE) FROM Employee))
)

--Multiple Row SubQuery(Subquery Returns more than one Row)
SELECT AGE FROM Employee WHERE AGE > ALL(SELECT Age FROM Employee WHERE AGE BETWEEN 24 AND 34)

-- Correlated SubQuery(subquery depends on the outer query for its values)
SELECT AGE FROM EMPLOYEE WHERE AGE < (SELECT MAX(AGE) FROM Employee)

-- Modify a Column
ALTER TABLE EMPLOYEE MODIFY COLUMN CITY VARCHAR(250) 

-- DROP a Column
ALTER TABLE EMPLOYEE DROP COLUMN AGE 

-- COMPUTE
SELECT EmployeeID,EmployeeName,Age,City FROM Employee COMPUTE AVG(AGE)

-- COMPUTE BY
SELECT EmployeeID,EmployeeName,Age,City FROM Employee ORDER BY CITY COMPUTE AVG(AGE) BY CITY


DROP TABLE EMPLOYEE
DROP TABLE DEPARTMENT

--JOINS
CREATE TABLE Department(DeptID INT,DeptName VARCHAR(25))
INSERT INTO Department(DeptID,DeptName) VALUES (1,'Computer')
INSERT INTO Department(DeptID,DeptName) VALUES (2,'Accounts')
INSERT INTO Department(DeptID,DeptName) VALUES (3,'Maths')
INSERT INTO Department(DeptID,DeptName) VALUES (4,'Arts')
INSERT INTO Department(DeptID,DeptName) VALUES (5,'Sports')
INSERT INTO Department(DeptID,DeptName) VALUES (6,'NCC')


CREATE TABLE STUDENT(ID INT PRIMARY KEY,StudentName VARCHAR(25),DeptID INT)
INSERT INTO STUDENT(ID,StudentName,DeptID) VALUES (101,'Abishek',5)
INSERT INTO STUDENT(ID,StudentName,DeptID) VALUES (102,'Ganesh',4)
INSERT INTO STUDENT(ID,StudentName,DeptID) VALUES (103,'Shilpa',2)
INSERT INTO STUDENT(ID,StudentName,DeptID) VALUES (104,'Ajit',3)
INSERT INTO STUDENT(ID,StudentName,DeptID) VALUES (105,'Selva',2)
INSERT INTO STUDENT(ID,StudentName,DeptID) VALUES (106,'Karthik',1);
INSERT INTO STUDENT(ID,StudentName,DeptID) VALUES (107,'Mohan',8);

--INNER JOIN(EQUI Join)
SELECT ID,StudentName,DeptName FROM STUDENT INNER JOIN Department ON STUDENT.DeptID = Department.DeptID

--INNER JOIN(NON EQUI Join)
SELECT ID,StudentName,DeptName FROM STUDENT INNER JOIN Department ON STUDENT.DeptID <> Department.DeptID where ID =101

-- LEFT OUTER JOIN
SELECT ID,StudentName,DeptName FROM STUDENT LEFT OUTER JOIN Department ON STUDENT.DeptID = Department.DeptID

-- RIGHT OUTER JOIN
SELECT ID,StudentName,DeptName FROM STUDENT RIGHT OUTER JOIN Department ON STUDENT.DeptID = Department.DeptID

-- FULL OUTER JOIN
SELECT ID,StudentName,DeptName FROM STUDENT FULL OUTER JOIN Department ON STUDENT.DeptID = Department.DeptID

--CROSS JOIN
SELECT Student.ID,Department.DeptID FROM Student CROSS JOIN Department

-- SELF JOIN
CREATE Table Employee(EmployeeID INT, EmployeeName VARCHAR(20),ManagerID INT)
INSERT INTO EMPLOYEE VALUES(101,'KARTHIK',102)
INSERT INTO EMPLOYEE VALUES(102,'LATHA',103)
INSERT INTO EMPLOYEE VALUES(103,'VEENA',103)
INSERT INTO EMPLOYEE VALUES(104,'ABISHEK',102)

SELECT T1.EmployeeName,T2.EmployeeName AS Manager FROM Employee T1 INNER JOIN Employee T2 ON T2.EmployeeID = T1.ManagerID

-- Index
-- Creating Default Clustered Index and Non Clustered Index using Primary Key and Unique Key
CREATE TABLE Person(PersonID INT CONSTRAINT pkPersonID PRIMARY KEY, PersonName VARCHAR(20),EmailID VARCHAR(50),PanNumber CHAR(10) CONSTRAINT uqPanNumber UNIQUE,PassportNumber VARCHAR(20));
SP_HELP Person

-- Creating Clustered Index(A table can have only 1 Clustered Index) 
CREATE CLUSTERED INDEX pk1PersonID ON Person(PersonID)

-- Creating NONCLUSTERED Index on SecondaryKey
CREATE NONCLUSTERED INDEX nciEmailID ON Person(EmailID)
CREATE NONCLUSTERED INDEX nci1EmailID ON Person(EmailID)

-- information about Index on Tables
SP_HELPINDEX  Person

-- Droping NONCLUSTERED Index 
DROP INDEX Person.nci1EmailID

-- Creating Composite Indexes
CREATE NONCLUSTERED INDEX nciEmailPass ON Person(EmailID,PassportNumber)
DROP INDEX Person.nciEmailPass

DROP TABLE Person

--Views
CREATE TABLE Category(CategoryID INT PRIMARY KEY,CategoryName VARCHAR(25))
INSERT INTO Category(CategoryID,CategoryName) VALUES (1,'Personal Computers')
INSERT INTO Category(CategoryID,CategoryName) VALUES (2,'Laptop')
INSERT INTO Category(CategoryID,CategoryName) VALUES (3,'Printers')


CREATE TABLE Product(ProductID INT PRIMARY KEY,ProductName VARCHAR(25),Price INT, CategoryID INT)
INSERT INTO Product(ProductID,ProductName,Price,CategoryID) VALUES (101,'PC-1223',30000,1)
INSERT INTO Product(ProductID,ProductName,Price,CategoryID) VALUES (102,'LP-1223',25000,2)
INSERT INTO Product(ProductID,ProductName,Price,CategoryID) VALUES (103,'PRI-1223',3000,3)
INSERT INTO Product(ProductID,ProductName,Price,CategoryID) VALUES (104,'PC-1263',28000,1)
INSERT INTO Product(ProductID,ProductName,Price,CategoryID) VALUES (105,'LP-1264',34000,2)
INSERT INTO Product(ProductID,ProductName,Price,CategoryID) VALUES (106,'PRI-1623',4000,3)

-- CREATING VIEW
CREATE VIEW ProductCategoryView  AS
SELECT ProductID, ProductName, Price, CategoryName
FROM  Product INNER JOIN
Category ON Product.CategoryID = Category.CategoryID

-- Working With View (SELECT)
SELECT ProductName,Price,CategoryName FROM ProductCategoryView

-- Working With View (Update)
UPDATE ProductCategoryView SET Price = Price + 100 

-- Working With View (INSERT)
INSERT INTO ProductCategoryView(ProductID, ProductName, Price, CategoryName) VALUES (107,'PC-4556',3200,'Personal Computers')
INSERT INTO ProductCategoryView(ProductID, ProductName, Price) VALUES (107,'PC-4556',3200)

SELECT * FROM Product

-- Altering View
ALTER VIEW ProductCategoryView  AS
SELECT ProductID, ProductName, Price, CategoryName
FROM  Product LEFT OUTER JOIN
Category ON Product.CategoryID = Category.CategoryID

SELECT ProductName,Price,CategoryName FROM ProductCategoryView

-- Dropping View
DROP VIEW ProductCategoryView

SELECT TOP(2) ProductID FROM PRODUCT